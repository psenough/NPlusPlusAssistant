Thank you for downloading the localization fix for N++.

Installation
====================
To play the game with the fix, navigate to the following folder ...

Windows - C:\Program Files (x86)\Steam\steamapps\common\N++\NPP
Mac     - ~/Library/Application Support/Steam/steamapps/common/N++/N++/Contents/Resources/NPP
Linux   - ~/.steam/steam/steamapps/common/N++/NPP

... and replace the 'loc.txt' file with the one contained in this pack.


Additional Notes
====================
• In case you want to change the in-game language on Steam, right-click N++ on the sidebar and navigate to Properties... -> Language

• Back up your savefile before launching the game with the pack.
  (This is not because anything bad will happen to it per se, but because you should be backing up your savefile anyway.)
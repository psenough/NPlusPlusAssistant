Thanks for downloading, I hope you enjoy your time with Vz++!

To play with Vz++, navigate to the following folder...

Windows - C:\Program Files (x86)\Steam\steamapps\common\N++\NPP
Mac - 	~/Library/Application Support/Steam/steamapps/common/N++/N++/Contents/Resources/NPP
Linux - ~/.steam/steam/steamapps/common/N++/NPP

...and replace* the `loc.txt` file found there with the one contained in this pack.


IMPORTANT:
(A copy of a completly unedited loc.txt file titled `loc_default.txt` can be found in the folder, just in case.)
*(If you already use a modified loc.txt file, make sure to keep it somewhere safe and do not replace it.)
(The in-game language has to be set to English for any effect to take place.)
(Additionally, back up your savefile before using Vz++. Not because anything bad will happen with it per se, but because you should be backing up your savefile anyways.)
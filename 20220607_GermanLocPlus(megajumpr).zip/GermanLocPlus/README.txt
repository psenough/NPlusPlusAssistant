Thank you for downloading the "GermanLocPlus" textpack, I hope you enjoy your time with it!

To play with the pack, navigate to the following folder...

Windows - C:\Program Files (x86)\Steam\steamapps\common\N++\NPP
Mac - 	~/Library/Application Support/Steam/steamapps/common/N++/N++/Contents/Resources/NPP
Linux - ~/.steam/steam/steamapps/common/N++/NPP

...and replace* the "loc.txt" file found there with the one contained in this pack.


IMPORTANT:
- The in-game language has to be set to German for any effect to take place.
- A copy of an unedited loc.txt file titled "loc_default.txt" can be found in the folder to switch back between regular and modified text.
- Additionally, back up your savefile before launching your game with the pack. Not because anything bad will happen to it per se, but because you should be backing up your savefile anyways.

*If you use a self-modified loc.txt file, make sure to move it somewhere safe and do NOT replace it if you wish to keep it.